package apps.pixel.al.egykey.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;

import java.util.List;

import apps.pixel.al.egykey.R;
import apps.pixel.al.egykey.utilities.CairoBoldTextView;
import de.hdodenhof.circleimageview.CircleImageView;

public class RestaurantAdapter extends RecyclerView.Adapter<RestaurantAdapter.ViewHolder> {

    private final OnClickHandler onClickHandler;
    private final List<String> arabicNames;
    private final List<String> englishNames;
    private final List<String> urlsBackGrounds;
    private final List<String> urlsLogos;
    private Context context;

    public RestaurantAdapter(Context context, List<String> arabicNames, List<String> englishNames, List<String> urlsBackGrounds, List<String> urlsLogos, OnClickHandler onClickHandler) {
        this.context = context;
        this.arabicNames = arabicNames;
        this.englishNames = englishNames;
        this.urlsLogos = urlsLogos;
        this.urlsBackGrounds = urlsBackGrounds;
        this.onClickHandler = onClickHandler;
    }

    @Override
    public int getItemCount() {
        return arabicNames == null ? 0 : arabicNames.size();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.restaurant_item_layout, parent, false);
        return new ViewHolder(view);
    }

    private void removeAt(int position) {
        arabicNames.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, arabicNames.size());
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, final int listPosition) {

        try {
            holder.titleArabic.setText(arabicNames.get(listPosition));
            holder.titleEnglish.setText(englishNames.get(listPosition));


            Glide.with(context)
                    .load(urlsLogos.get(listPosition))
                    .placeholder(R.drawable.placeholder_logo)
                    .into(holder.imgLogo);

            Glide.with(context)
                    .load(urlsLogos.get(listPosition))
                    .placeholder(R.drawable.test)
                    .into(holder.imgBgRetaurant);


        } catch (NullPointerException ignored) {

        }
    }

    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }

    public interface OnClickHandler {
        void onClick(int position);
    }

    class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private AppCompatImageView imgBgRetaurant;
        private CircleImageView imgLogo;
        private CairoBoldTextView titleEnglish;
        private CairoBoldTextView titleArabic;


        ViewHolder(View itemView) {
            super(itemView);

            initViews(itemView);
        }

        private void initViews(View itemView) {
            imgBgRetaurant = itemView.findViewById(R.id.img_bg_retaurant);
            imgLogo = itemView.findViewById(R.id.img_logo);
            titleEnglish = itemView.findViewById(R.id.title_english);
            titleArabic = itemView.findViewById(R.id.title_arabic);

            itemView.setOnClickListener(this);

        }

        @Override
        public void onClick(View view) {
            int position = getAdapterPosition();
            onClickHandler.onClick(position);
        }
    }
}
