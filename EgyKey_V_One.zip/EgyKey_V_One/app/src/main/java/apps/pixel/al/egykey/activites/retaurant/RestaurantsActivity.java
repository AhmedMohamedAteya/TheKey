package apps.pixel.al.egykey.activites.retaurant;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import apps.pixel.al.egykey.R;
import apps.pixel.al.egykey.adapters.RestaurantAdapter;
import apps.pixel.al.egykey.utilities.Constant;

public class RestaurantsActivity extends AppCompatActivity implements RestaurantAdapter.OnClickHandler {

    private RecyclerView mRv;
    private List<String> arabicNames;
    private List<String> englishNames;
    private List<String> logoUrls;
    private List<String> bgUrls;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.restaurants_activity_main);

        initViews();
    }

    private void initViews() {
        arabicNames = new ArrayList<>();
        englishNames = new ArrayList<>();
        logoUrls = new ArrayList<>();
        bgUrls = new ArrayList<>();

        arabicNames.add("test");
        arabicNames.add("test");
        arabicNames.add("test");

        englishNames.add("test");
        englishNames.add("test");
        englishNames.add("test");

        logoUrls.add("https://www.google.com/url?sa=i&source=images&cd=&ved=2ahUKEwj05rWFm-nkAhXaAGMBHUihBwoQjRx6BAgBEAQ&url=https%3A%2F%2Fwww.businessinsider.com%2Fmcdonalds-is-launching-a-new-giant-big-mac-in-the-uk-today-2018-2&psig=AOvVaw15OTYxJMRKxqW3yBzox-BZ&ust=1569405981202507");
        logoUrls.add("https://www.google.com/url?sa=i&source=images&cd=&ved=2ahUKEwj05rWFm-nkAhXaAGMBHUihBwoQjRx6BAgBEAQ&url=https%3A%2F%2Fwww.businessinsider.com%2Fmcdonalds-is-launching-a-new-giant-big-mac-in-the-uk-today-2018-2&psig=AOvVaw15OTYxJMRKxqW3yBzox-BZ&ust=1569405981202507");
        logoUrls.add("https://www.google.com/url?sa=i&source=images&cd=&ved=2ahUKEwj05rWFm-nkAhXaAGMBHUihBwoQjRx6BAgBEAQ&url=https%3A%2F%2Fwww.businessinsider.com%2Fmcdonalds-is-launching-a-new-giant-big-mac-in-the-uk-today-2018-2&psig=AOvVaw15OTYxJMRKxqW3yBzox-BZ&ust=1569405981202507");

        bgUrls.add("https://www.google.com/url?sa=i&source=images&cd=&ved=2ahUKEwiH9YSYm-nkAhWp0eAKHW7kADkQjRx6BAgBEAQ&url=https%3A%2F%2Fwww.thrillist.com%2Fnews%2Fnation%2Fmcdonalds-free-big-macs-maccoins-2018&psig=AOvVaw15OTYxJMRKxqW3yBzox-BZ&ust=1569405981202507");
        bgUrls.add("https://www.google.com/url?sa=i&source=images&cd=&ved=2ahUKEwiH9YSYm-nkAhWp0eAKHW7kADkQjRx6BAgBEAQ&url=https%3A%2F%2Fwww.thrillist.com%2Fnews%2Fnation%2Fmcdonalds-free-big-macs-maccoins-2018&psig=AOvVaw15OTYxJMRKxqW3yBzox-BZ&ust=1569405981202507");
        bgUrls.add("https://www.google.com/url?sa=i&source=images&cd=&ved=2ahUKEwiH9YSYm-nkAhWp0eAKHW7kADkQjRx6BAgBEAQ&url=https%3A%2F%2Fwww.thrillist.com%2Fnews%2Fnation%2Fmcdonalds-free-big-macs-maccoins-2018&psig=AOvVaw15OTYxJMRKxqW3yBzox-BZ&ust=1569405981202507");

        mRv = findViewById(R.id.rv);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        mRv.setLayoutManager(layoutManager);

        loadRecyclerData();


    }

    public void loadRecyclerData() {
        RestaurantAdapter adapter = new RestaurantAdapter(this, arabicNames, englishNames, bgUrls, logoUrls, this);
        mRv.setAdapter(adapter);
        Constant.runLayoutAnimation(mRv);

    }

    @Override
    public void onClick(int position) {

    }
}
